module.exports = {

    resolve: {
      fallback: { "assert": false },
    },
  };